/*Debemos lograr tomar un nombre con 'prompt' 
y luego mostrarlo por 'alert' al presionar el botón  'MOSTRAR'*/
function Mostar()
{
	//esto es un comentario de una linea
    //alert("anda");
	//toda linea de instruccion termina con punto y coma (;)
	var nombre;
/*
es un bloque
    alert("nombre");
    alert(nombre);
    nombre="alejandro"
    alert(nombre)
*/
  //  var person = prompt("Please enter your name", "Harry Potter");

nombre=prompt("ingrese su nombre","natalia natalia"); 
alert(nombre);

alert("sunombre es:"+ nombre);

}

