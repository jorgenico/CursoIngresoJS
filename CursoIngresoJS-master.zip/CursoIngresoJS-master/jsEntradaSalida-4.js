/* 
	Debemos lograr tomar un dato por 'PROMPT' 
	y lo muestro por 'getElementById' al presionar el botón 'MOSTRAR'
*/
function Mostar()
{
	var nombre;
	nombre= prompt("porfavor ingresa tu nombre");
	document.getElementById('elNombre').value= nombre 
	//el igual se pone al final para que 

}

