/*Debemos lograr tomar el importe por ID.
Transformarlo a entero (parseInt), luego
mostrar el importe con un Descuento del 25 %
en el cuadro de texto "RESULTADO"*/
function MostrarAumento()
{
	var importe;
	var resultado;
	var descuento;

	importe=document.getElementById('importe');
	importe=parseInt(importe);

	resultado=getElementById(resultado);
	resultado=parseInt(resultado);


	descuento=importe*25/100=descuento;
	descuento=descuento+importe=resultado;

	resultado=getElementById(resultado).value=;

//me pierdo como en el ejercicio anterior, con el temma de mostrar descuento que aparece en la parte de HTML.-
}
