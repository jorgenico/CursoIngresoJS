/* 
	Debemos lograr tomar un dato por 'PROMPT' 
	y lo muestro por 'getElementById' al presionar el botón 'MOSTRAR'
*/
function Mostar()
{
	var nombre;
	nombre=prompt("ingrese su nombre por favor");
	document.getElementById("elNombre").value=nombre;
	//el igual se pone al final para que 

}

