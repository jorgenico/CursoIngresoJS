function Mostrar()
{

	var contador=0;
	//declarar contadores y variables 
	
	var respuesta="si";

	while(respuesta!="no")
	{
		
	
	}




}//FIN DE LA FUNCIÓN